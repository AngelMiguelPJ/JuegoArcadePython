import pygame
import sys

#Creacion de clase del boton 1
class Cursor(pygame.Rect):
    def __init__(self):
        pygame.Rect.__init__(self,0,0,1,1)
    def update(self):
        self.left,self.top = pygame.mouse.get_pos()

#Creacion del boton1
class Boton1(pygame.sprite.Sprite):
    def __init__(self, imagen1, imagen2, x = 550, y = 200):
        self.imagen_normal = imagen1
        self.imagen_seleccion = imagen2
        self.imagen_actual = self.imagen_normal
        self.rect = self.imagen_actual.get_rect()
        self.rect.left, self.rect.top = (x,y)

    def update(self, pantalla, cursor):
        if cursor.colliderect(self.rect):
            self.imagen_actual = self.imagen_seleccion
        else:
            self.imagen_actual = self.imagen_normal
            
        pantalla.blit(self.imagen_actual,self.rect)
        
#Creacion del boton2
class Boton2(pygame.sprite.Sprite):
    def __init__(self, imagen1, imagen2, x = 550, y = 300):
        self.imagen_normal = imagen1
        self.imagen_seleccion = imagen2
        self.imagen_actual = self.imagen_normal
        self.rect = self.imagen_actual.get_rect()
        self.rect.left, self.rect.top = (x,y)

    def update(self, pantalla, cursor):
        if cursor.colliderect(self.rect):
            self.imagen_actual = self.imagen_seleccion
        else:
            self.imagen_actual = self.imagen_normal
            
        pantalla.blit(self.imagen_actual,self.rect)

#Creacion del boton3
class Boton3(pygame.sprite.Sprite):
    def __init__(self, imagen1, imagen2, x = 550, y = 400):
        self.imagen_normal = imagen1
        self.imagen_seleccion = imagen2
        self.imagen_actual = self.imagen_normal
        self.rect = self.imagen_actual.get_rect()
        self.rect.left, self.rect.top = (x,y)

    def update(self, pantalla, cursor):
        if cursor.colliderect(self.rect):
            self.imagen_actual = self.imagen_seleccion
        else:
            self.imagen_actual = self.imagen_normal
            
        pantalla.blit(self.imagen_actual,self.rect)



#Creacion de la segunda pantalla para el 1 vs cpu    
def Pantalla2():
    import JuegoPart1

#Creacion de la segunda pantalla para el 1 vs 1   
def Pantalla3():
    import JuegoPart2

def main():
    
    #Creacion de la pantalla principal
    #Inicamos la pantalla
    pygame.init()
    #Configuramos la pantalla
    pantalla = pygame.display.set_mode([1250,600])
    #Titulo de la pantalla
    pygame.display.set_caption("Space invaders")
    #Color de la letras
    blanco = (255,255,255)
    negro = (0,0,0)
    #Texto en la pantalla
    fuente = pygame.font.Font(None, 80)
    titulo = fuente.render("Space Invaders", 0 , blanco)
    #Imagen de fonde de pantalla
    fondo = pygame.image.load("fondo.png").convert_alpha()
    #La velocidad de la pantalla
    reloj = pygame.time.Clock()
    #Condicion para salir
    salir = False
    #Creamos el cursos
    cursor1 = Cursor()
    #Creamos el boton 1
    boton1Color1 = pygame.image.load("boton1.1.png").convert_alpha()
    boton1Color2 = pygame.image.load("boton1.2.png").convert_alpha()
    boton1 = Boton1(boton1Color1, boton1Color2)
    #Creamos el boton 2
    boton2Color1 = pygame.image.load("boton2.png")
    boton2Color2 = pygame.image.load("boton2-2.png")
    boton2 = Boton2(boton2Color1, boton2Color2)

    #Creamos la imagen de la nave animada 1
    nave_animada = pygame.image.load("enemigo2.png").convert_alpha()
    nave_posicionX = 5
    nave_posicionY = 25
    nave_animada_velocidad = 5
    derecha = True
    #Creamos la imagen de la nave animada 2
    nave2_animada = pygame.image.load("enemigo1.png").convert_alpha()
    nave2_posicionX = 900
    nave2_posicionY = 25
    nave2_animada_velocidad = 5
    derecha = True

    #musica
    pygame.mixer.music.load('SpaceMusic.mp3')
    pygame.mixer.music.play(5) 
    
    #Clico while para que se repitan eventos mientras no demos en la x
    while salir != True:
        #evento
        for event in pygame.event.get():
            #Condicionales para cuando apretamos el raton
            if event.type == pygame.MOUSEBUTTONDOWN:
                if cursor1.colliderect(boton1.rect):
                    Pantalla2()
                    pygame.mixer.music.fadeout(2000)
                    break
                elif cursor1.colliderect(boton2.rect):
                    Pantalla3()
                    pygame.mixer.music.fadeout(2000)
                    break
            
            if event.type == pygame.QUIT:
                salir = True
                pygame.mixer.music.fadeout(2000)
        #Tiempo
        reloj.tick(20)
        #Fondo
        pantalla.blit(fondo,(0,0))
        #Titulo
        pantalla.blit(titulo,(425,25))
        #Dibujamos la nave animada 1
        pantalla.blit(nave_animada,(nave_posicionX,nave_posicionY))
        if derecha == True:
            if nave_posicionX < 450:
                nave_posicionX += nave_animada_velocidad
            else:
                derecha = False
        else:
            if nave_posicionX > 5:
                nave_posicionX -= nave_animada_velocidad
            else:
                derecha = True
        #Dibujamos la nave animada 2
        pantalla.blit(nave2_animada,(nave2_posicionX,nave2_posicionY))
        if derecha == True:
            if nave2_posicionX < 1200:
                nave2_posicionX += nave2_animada_velocidad
            else:
                derecha = False
        else:
            if nave2_posicionX > 850:
                nave2_posicionX -= nave2_animada_velocidad
            else:
                derecha = True
        #Cursor
        cursor1.update()
        #boton1
        boton1.update(pantalla,cursor1)
        #boton2
        boton2.update(pantalla,cursor1)

        #pantalla
        pygame.display.update()


        
            

    pygame.quit()
    



main()
