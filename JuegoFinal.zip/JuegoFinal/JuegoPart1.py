import pygame
import random
import sys
from random import randint


#Creacion de clase del boton 1


#Creacion del nave1
# Crear la Nave 1
class NaveEspacial(pygame.sprite.Sprite):
    # Inicializar la nave
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.nave = pygame.image.load("ship.png").convert_alpha()
        self.rect = self.nave.get_rect()
        self.rect.x = 10
        self.rect.y = 250
        self.listaDisparos = []
        self.vida = True
        self.velocidad = 5
        self.SonidoDisparo = pygame.mixer.Sound('laser.wav')
    
    # Movimiento de la nave
    def Movimiento(self, pantalla):
        key = pygame.key.get_pressed()
        if key[pygame.K_UP]:
            self.rect.y -= self.velocidad
            if self.rect.y < 5:
                self.rect.y = 5
        elif key[pygame.K_DOWN]:
            self.rect.y += self.velocidad
            if self.rect.y > 505 :
                self.rect.y = 505
        elif key[pygame.K_SPACE]:
            x = self.rect.x
            y = self.rect.y
            self.disparar(x,y)                    
                
    #Metodo disparar la nave
    def disparar(self, x, y):
        laser = laserNave(x,y)
        self.listaDisparos.append(laser)
        self.SonidoDisparo.play()
        

    # dibujar la nave en la pantalla
    def dibujarNave(self, pantalla):
        pantalla.blit(self.nave,self.rect)

#Crearemos el laser de la nave 1
class laserNave(pygame.sprite.Sprite):
    #Inicializacion del laser
    def __init__(self, posx, posy):
        pygame.sprite.Sprite.__init__(self)
        self.laser = pygame.image.load("laser.png").convert_alpha()
        self.rect = self.laser.get_rect()
        self.velocidadLaser = 8
        self.rect.x = posx + 42
        self.rect.y = posy + 22

    #Trayectoria
    def trayectoria(self):
        self.rect.x += self.velocidadLaser

    #Dibujar el laser
    def dibujarLaser(self, pantalla):
        pantalla.blit(self.laser,self.rect)

#-------------------------------------------------------------------------------#
#Crearemos los invasores
class Invasorj1(pygame.sprite.Sprite):
    #Inicializacion el invasor
    def __init__(self, posx, posy):
        pygame.sprite.Sprite.__init__(self)
        self.invasor = pygame.image.load("enemigo1.png").convert_alpha()
        self.rect = self.invasor.get_rect()
        self.velocidad = 5
        self.rect.x = posx
        self.rect.y = posy
        #movimiento
        self.abajo = True
        self.contador = 0
        self.Maxdesp = self.rect.x - 10

    #Movimiento del invasor
    def Movimiento(self,pantalla):
        if self.contador < 3:
            self.movimientoAbajo()
        else:
            self.movimientoLateral()

    #Movimiento del invasor hacia la izquiera
    def movimientoLateral(self):
        if self.Maxdesp == self.rect.x:
            self.contador = 0
            self.Maxdesp = self.rect.x - 10
            self.velocidad += 0.5
        else:
            self.rect.x -= 1
            
    #Mivimiento del invasor hacia la derecha
    def movimientoAbajo(self):
        if self.abajo == True:
            self.rect.y += self.velocidad
            if self.rect.y > 525:
                self.abajo = False
                self.contador +=1
        if self.abajo == False:
            self.rect.y -= self.velocidad
            if self.rect.y < 10:
                self.abajo = True
            

    #Dibujar el envasor
    def dibujarInvasor(self, pantalla):
        pantalla.blit(self.invasor,self.rect)          

#Vriables globales enemigos
numeroEnemigoj1 = 3
listaEnemigoj1 = []
#Crear los invasores       
def cargarEnemigosj1():
    for enemigo in range(numeroEnemigoj1):
        posx = randint(430,480)
        posy = randint(10,280)
        enemigo = Invasorj1(posx,posy)
        listaEnemigoj1.append(enemigo)
        posy += 200
    for enemigo in range(numeroEnemigoj1):
        posx = randint(500,550)
        posy = randint(280,525)
        enemigo = Invasorj1(posx,posy)
        listaEnemigoj1.append(enemigo)
        posy += 400
    for enemigo in range(numeroEnemigoj1):
        posx = randint(770,820)
        posy = randint(280,525)
        enemigo = Invasorj1(posx,posy)
        listaEnemigoj1.append(enemigo)
        posy += 400
    for enemigo in range(numeroEnemigoj1):
        posx = randint(840,890)
        posy = randint(280,525)
        enemigo = Invasorj1(posx,posy)
        listaEnemigoj1.append(enemigo)
        posy += 400

#-----------------------------------------------------------------------------#
#Crearemos los invasores
class Invasorj2(pygame.sprite.Sprite):
    #Inicializacion el invasor
    def __init__(self, posx, posy):
        pygame.sprite.Sprite.__init__(self)
        self.invasor = pygame.image.load("enemigo2.png").convert_alpha()
        self.rect = self.invasor.get_rect()
        self.velocidad = 8
        self.rect.x = posx
        self.rect.y = posy
        #movimiento
        self.abajo = True
        self.contador = 0
        self.Maxdesp = self.rect.x - 10

    #Movimiento del invasor
    def Movimiento(self,pantalla):
        if self.contador < 3:
            self.movimientoAbajo()
        else:
            self.movimientoLateral()

    #Movimiento del invasor hacia la izquiera
    def movimientoLateral(self):
        if self.Maxdesp == self.rect.x:
            self.contador = 0
            self.Maxdesp = self.rect.x - 10
            self.velocidad += 0.5
        else:
            self.rect.x -= 1
            
    #Mivimiento del invasor hacia la derecha
    def movimientoAbajo(self):
        if self.abajo == True:
            self.rect.y -= self.velocidad
            if self.rect.y < 10:
                self.abajo = False
                self.contador +=1
        if self.abajo == False:
            self.rect.y += self.velocidad
            if self.rect.y > 525:
                self.abajo = True
            

    #Dibujar el envasor
    def dibujarInvasor(self, pantalla):
        pantalla.blit(self.invasor,self.rect)          

#Vriables globales enemigos
numeroEnemigoj2 = 3
listaEnemigoj2 = []
#Crear los invasores       
def cargarEnemigosj2():
    for enemigo in range(numeroEnemigoj2):
        posx = randint(600,650)
        posy = randint(10,280)
        enemigo = Invasorj2(posx,posy)
        listaEnemigoj2.append(enemigo)
        posy += 200
    for enemigo in range(numeroEnemigoj2):
        posx = randint(670,720)
        posy = randint(280,525)
        enemigo = Invasorj2(posx,posy)
        listaEnemigoj2.append(enemigo)
        posy += 400
    for enemigo in range(numeroEnemigoj2):
        posx = randint(910,960)
        posy = randint(10,280)
        enemigo = Invasorj2(posx,posy)
        listaEnemigoj2.append(enemigo)
        posy += 200
    for enemigo in range(numeroEnemigoj2):
        posx = randint(980,1030)
        posy = randint(280,525)
        enemigo = Invasorj2(posx,posy)
        listaEnemigoj2.append(enemigo)
        posy += 400
#-----------------------------------------------------------------------------#
def main():
    
    #Iniciamos pygame
    pygame.init()
    # variables de pantalla
    ancho = 1250
    alto = 600
    #musica
    pygame.mixer.music.load('SpaceMusic.mp3')
    pygame.mixer.music.play(5) 
    # creamos la pantalla o ventana de juego
    pantalla = pygame.display.set_mode((ancho,alto))
    #Creamos el titulo de la ventana
    pygame.display.set_caption("Space Invaders")
    #Imagen de fonde de pantalla
    fondo = pygame.image.load("fondo.png").convert_alpha()
    #Creamos objeto
    jugador = NaveEspacial()
    #Creamos el segundo objeto
    laser = laserNave(10,280)
    #CREAMOS LOS INVASORES
    cargarEnemigosj1()
    cargarEnemigosj2()
    #Variables del juego
    juego = True
    salir = False
    #Tiempo de juego
    reloj = pygame.time.Clock()


    #Creamos el ciclo while para sali o no del juego

    while salir != True:
        #evento
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                salir = True

        # reloj para el tiempo de ejecucion
        reloj.tick(60)
        #Fondo
        pantalla.blit(fondo,(0,0))
        # dibujamos el jugador
        jugador.dibujarNave(pantalla)
        jugador.Movimiento(pantalla)
        

        #Condicion de disparos jugador 1
        if len(jugador.listaDisparos) > 0:
                for x in jugador.listaDisparos:
                    x.dibujarLaser(pantalla)
                    x.trayectoria()
                    if x.rect.x > 1225:
                        jugador.listaDisparos.remove(x)
                    else:
                        for enemigo in listaEnemigoj1:
                            if x.rect.colliderect(enemigo.rect):
                                listaEnemigoj1.remove(enemigo)
                                jugador.listaDisparos.remove(x)
                        for enemigo in listaEnemigoj2:
                            if x.rect.colliderect(enemigo.rect): 
                                listaEnemigoj2.remove(enemigo)
                                jugador.listaDisparos.remove(x)

        #Imprimimos la lista de los invasores jugador 1                     
        if len(listaEnemigoj1) > 0:
            for enemigo in listaEnemigoj1:
                enemigo.dibujarInvasor(pantalla)
                enemigo.Movimiento(pantalla)
                if enemigo.rect.colliderect(jugador.rect):
                    blanco = (255,255,255)
                    fuente = pygame.font.Font(None, 80)
                    titulo = fuente.render("CPU WIN", 0 , blanco)
                    pantalla.blit(titulo,(425,200))
                    pygame.display.update()
                    pygame.mixer.music.fadeout(2000)
                    sys.exit()
                    
        if len(listaEnemigoj2) > 0:
            for enemigo in listaEnemigoj2:
                enemigo.dibujarInvasor(pantalla)
                enemigo.Movimiento(pantalla)
                if enemigo.rect.colliderect(jugador.rect):
                    blanco = (255,255,255)
                    fuente = pygame.font.Font(None, 80)
                    titulo = fuente.render("CPU WIN", 0 , blanco)
                    pantalla.blit(titulo,(425,200))
                    pygame.display.update()
                    pygame.mixer.music.fadeout(2000)
                    sys.exit()
                    
        if len(listaEnemigoj1) == 0 and len(listaEnemigoj2) == 0:
            blanco = (255,255,255)
            fuente = pygame.font.Font(None, 80)
            titulo = fuente.render("YOU WIN", 0 , blanco)
            pantalla.blit(titulo,(450,200))
            pygame.display.update()
            pygame.mixer.music.fadeout(2000)
            sys.exit()

        
        #pantalla
        pygame.display.update()



main()










